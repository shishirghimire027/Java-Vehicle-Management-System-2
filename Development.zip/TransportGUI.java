import javax.swing.*;
import java.util.*;
import java.awt.Font;
import java.awt.event.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.JLabel;

public class TransportGUI implements ActionListener
{
    ArrayList<Vehicle> ccr = new ArrayList<Vehicle>();
    
    
    public JFrame frame;
    public JPanel panel, panel2,pp1,pp2,ppp1,ppp2,ppp3,p1;
    public JLabel label1, label2, label3, label4, label5, label6, label7, label8, label9, label10, label11, label12, label13, label14, label15, label16, label17, label18, label19,
    l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,l16,l17,l18,lcap;
    public JTextField tf1, tf2, tf3, tf4, tf5, tf6, tf7, tf8, tf9, tf10, tf11, tf12, tf13, tf14, tf15, tf16, tf17,
    tfd1,tfd2,tfd3,tfd4,tfd5,tfd6,tfd7,tfd8,tfd9,tfd10,tfd11,tfd12,tfd13,tfd14,tfd15,tfd16,tfd17;
    public JComboBox <String> year, month, day;
    public JButton b1,b2,b3,b4,b5,bb1,bb2,bb3,bb4,bb5,bb6;
    public Font font;
    
    public TransportGUI(){
            
        //adding frame
        frame = new JFrame("Transport GUI");
        frame.setLayout(null);
        frame.setBounds(250,70,900,520);
        frame.setVisible(true);
        
        //adding panel
        panel = new JPanel();
        panel.setLayout(null);
        panel.setBounds(0,0,900,720);
        panel.setBackground(Color.BLACK);
        
        //left panel
        pp1 = new JPanel();
        pp1.setLayout(null);
        pp1.setBounds(30,55,400,350);
        pp1.setBackground(Color.CYAN);
        
        
        //right panel
        pp2 = new JPanel();
        pp2.setLayout(null);
        pp2.setBounds(480,55,370,240);
        pp2.setBackground(Color.YELLOW);
        
        
       
        
        
        //left heading label
        label1 = new JLabel();
        label1.setText("ADD an AutoRickshaw");
        label1.setBounds(150,0,400,50);
        label1.setForeground(Color.white);
        panel.add(label1);
        
        //right heading label
        lcap = new JLabel();
        lcap.setText("BOOK an AutoRickshaw");
        lcap.setBounds(560,0,400,50);
        lcap.setForeground(Color.white);
        panel.add(lcap);
        
        
        //setting font
        Font fn = new Font("Aliseo Font Family-Sans Serif Font", Font.BOLD,18);
        label1.setFont(fn);
        lcap.setFont(fn);
        
        
        // first label
        label2 = new JLabel("Vehicle ID");
        label2.setBounds(50,90,150,20);
        panel.add(label2);
        
        //first text field
        tf1 = new JTextField();
        tf1.setBounds(230,90,150,20);
        panel.add(tf1);
        
        // second label
        label3 = new JLabel("Vehicle Name");
        label3.setBounds(50,125,150,20);
        panel.add(label3);
        
        //second text field
        tf2 = new JTextField();
        tf2.setBounds(230,125,150,20);
        panel.add(tf2);
        
        //third label
        label4 = new JLabel("Vehicle Color");
        label4.setBounds(50,160,150,20);
        panel.add(label4);
        
        //third text field
        tf3 = new JTextField();
        tf3.setBounds(230,160,150,20);
        panel.add(tf3);
        
        //fourth label
        label5 = new JLabel("Vehicle Speed");
        label5.setBounds(50,195,150,20);
        panel.add(label5);
        
        //fourth text field
        tf4 = new JTextField();
        tf4.setBounds(230,195,150,20);
        panel.add(tf4);
        
        //fifth label
        label6 = new JLabel("Vehicle Weight");
        label6.setBounds(50,230,150,20);
        panel.add(label6);
        
        
        //fifth text field
        tf5 = new JTextField();
        tf5.setBounds(230,230,150,20);
        panel.add(tf5);
        
        //sixth label
        label7 = new JLabel("Torque");
        label7.setBounds(50,265,150,20);
        panel.add(label7);
        
        //sixth text field
        tf6 = new JTextField();
        tf6.setBounds(230,265,150,20);
        panel.add(tf6);
        
        //seventh label
        label8 = new JLabel("Ground Clearance");
        label8.setBounds(50,300,150,20);
        panel.add(label8);
        
        //seventh text field
        tf7 = new JTextField();
        tf7.setBounds(230,300,150,20);
        panel.add(tf7);
        
        //eighth label
        label9 = new JLabel("Fuel Tank Capacity");
        label9.setBounds(50,335,150,20);
        panel.add(label9);
        
        //eight text field
        tf8 = new JTextField();
        tf8.setBounds(230,335,150,20);
        panel.add(tf8);
        
        
        //nineth label
        label10 = new JLabel("Engine Displacement");
        label10.setBounds(50, 370, 150,20);
        panel.add(label10);
        
        //nineth text field
        tf17 = new JTextField();
        tf17.setBounds(230,370,150,20);
        panel.add(tf17);
        
        //ninth label
        label10 = new JLabel("Vehicle ID");
        label10.setBounds(500,90,150,20);
        panel.add(label10);
        
    
        
        //ninth text field
        tf9 = new JTextField();
        tf9.setBounds(680,90,150,20);
        panel.add(tf9);
        
        //tenth label
        label11 = new JLabel("Charge Amount");
        label11.setBounds(500,125,150,20);
        panel.add(label11);
        
        //tenth text field
        tf10 = new JTextField();
        tf10.setBounds(680,125,150,20);
        panel.add(tf10);
        
        //eleventh label
        label12 = new JLabel("No of Seats");
        label12.setBounds(500,160,150,20);
        panel.add(label12);
        
        
        //eleventh text field
        tf11 = new JTextField();
        tf11.setBounds(680,160,150,20);
        panel.add(tf11);
        
       
        
        //18th label 
        label19 = new JLabel("Booked Date");
        label19.setBounds(500,195,150,20);
        panel.add(label19);
        
        
        String[] Ydate={"Year","2015","2016","2017","2018","2019","2020","2021","2022"};
        //combobox for year
        year = new JComboBox(Ydate);
        year.setBounds(680,195,70,20);
        panel.add(year);
        
        
        String[] Mdate={"Month", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"};
        //combox for month
        month = new JComboBox(Mdate);
        month.setBounds(760,195,70,20);
        panel.add(month);
        
        
        String[] Ddate={"Select Day","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32"};
        //combobox for day
        day = new JComboBox(Ddate);
        day.setBounds(710,230,100,20);
        panel.add(day);
        
        
        //Add an autorickshaw button
        b1 = new JButton("Add");
        b1.setBounds(80,430,90,30);
        panel.add(b1);
        
        
        //book an autorickshaw button
        b2 = new JButton("Book");
        b2.setBounds(680,320,90,30);
        panel.add(b2);
        
        
        //display button
        b3 = new JButton("Display");
        b3.setBounds(220,430,90,30);
        panel.add(b3);
        
        //clear button
        b4 = new JButton("Clear");
        b4.setBounds(540,320,90,30);
        panel.add(b4);
        
        
        //Next button
        b5 = new JButton("Go To Electric Scooter");
        b5.setBounds(570,410,180,30); 
        panel.add(b5);
        
        
        //second panel
        panel2 = new JPanel();
        panel2.setLayout(null);
        panel2.setBounds(0,0,900,720);
        panel2.setBackground(Color.BLACK);
        
        
        //second pannel left panel
        ppp1 = new JPanel();
        ppp1.setLayout(null);
        ppp1.setBounds(20,64,320,233);
        ppp1.setBackground(Color.CYAN);
        
        
        //second panel right panel
        ppp2 = new JPanel();
        ppp2.setLayout(null);
        ppp2.setBounds(480,64,340,215);
        ppp2.setBackground(Color.YELLOW);
        
        
        //second panel bottom-right panel
        ppp3 = new JPanel();
        ppp3.setLayout(null);
        ppp3.setBounds(480,355,340,78);
        ppp3.setBackground(Color.YELLOW);
        
        
        //second panel 1st label
        l1 = new JLabel();
        l1.setText("Add an Electric Scooter");
        l1.setBounds(90,0,400,50);
        l1.setFont(fn);
        l1.setForeground(Color.white);
        panel2.add(l1);
        
        //second panel right caption 
        l17 = new JLabel();
        l17.setText("Purchase an Electric Scooter");
        l17.setBounds(530,0,400,50);
        l17.setFont(fn);
        l17.setForeground(Color.white);
        panel2.add(l17);
        
        //2nd label
        l2 = new JLabel("Vehicle ID");
        l2.setBounds(30,80,150,20);
        panel2.add(l2);
        
        
        ///second panel 1st text field
        tfd1 = new JTextField();
        tfd1.setBounds(160,80,150,20);
        panel2.add(tfd1);
        
        
        //3rd label
        l3 = new JLabel("Vehicle Name");
        l3.setBounds(30,115,150,20);
        panel2.add(l3);
        
        
        //2nd text field
        tfd2 = new JTextField();
        tfd2.setBounds(160,115,150,20);
        panel2.add(tfd2);
        
        
        //4th label
        l4 = new JLabel("Vehicle Color");
        l4.setBounds(30,150,150,20);
        panel2.add(l4);
        
        //3rd text field
        tfd3 = new JTextField();
        tfd3.setBounds(160,150,150,20);
        panel2.add(tfd3);
        
        
        //5th label
        l5 = new JLabel("Vehicle Speed");
        l5.setBounds(30,185,150,20);
        panel2.add(l5);
        
        //4th text field
        tfd4 = new JTextField();
        tfd4.setBounds(160,185,150,20);
        panel2.add(tfd4);
        
        
        //6th label
        l6 = new JLabel("Vehicle Weight");
        l6.setBounds(30,220,150,20);
        panel2.add(l6);
        
        
        //5th text field
        tfd5 = new JTextField();
        tfd5.setBounds(160,220,150,20);
        panel2.add(tfd5);
        
        //7th label
        l7 = new JLabel("Battery Capacity");
        l7.setBounds(30,255,150,20);
        panel2.add(l7);
        
        //6th text field
        tfd6 = new JTextField();
        tfd6.setBounds(160,255,150,20);
        panel2.add(tfd6);
        
        
        //10th label
        l10 = new JLabel("Vehicle ID");
        l10.setBounds(500,80,150,20);
        panel2.add(l10);
        
        
        //9th text field
        tfd9 = new JTextField();
        tfd9.setBounds(630,80,150,20);
        panel2.add(tfd9);
        
        
        //11th  label
        l11 = new JLabel("Brand");
        l11.setBounds(500,115,150,20);
        panel2.add(l11);
        
        //tenth text field
        tfd10 = new JTextField();
        tfd10.setBounds(630,115,150,20);
        panel2.add(tfd10);
        
        //price label
        l18 = new JLabel("Price");
        l18.setBounds(500,150,150,20);
        panel2.add(l18);
        
        
        //price label text field
        tfd17 = new JTextField();
        tfd17.setBounds(630,150,150,20);
        panel2.add(tfd17);
        
        
        
        
        //12th label
        l12 = new JLabel("Charging Time");
        l12.setBounds(500,185,150,20);
        panel2.add(l12);
        
        
        //eleventh text field
        tfd11 = new JTextField();
        tfd11.setBounds(630,185,150,20);
        panel2.add(tfd11);
        
        
        //13th label
        l13 = new JLabel("Mileage");
        l13.setBounds(500,220,150,20);
        panel2.add(l13);
        
        
        //12th text field
        tfd12 = new JTextField();
        tfd12.setBounds(630,220,150,20);
        panel2.add(tfd12);
        
        
        //14th label
        l14 = new JLabel("Range");
        l14.setBounds(500,255,150,20);
        panel2.add(l14);
        
        
        //13th text field
        tfd13 = new JTextField();
        tfd13.setBounds(630,255,150,20);
        panel2.add(tfd13);
        
        
        
        //15th label
        l8 = new JLabel("Sell Electric Scooter");
        l8.setFont(fn);
        l8.setForeground(Color.white);
        l8.setBounds(582,325,180,20);
        panel2.add(l8);
        
        //16th label
        l9 = new JLabel("Vehicle ID");
        l9.setBounds(500,365,150,20);
        panel2.add(l9);
        
        //14th text field
        tfd14 = new JTextField();
        tfd14.setBounds(630,365,150,20);
        panel2.add(tfd14);
        
        
        
        //17th label
        l16 = new JLabel("Price");
        l16.setBounds(500,400,150,20);
        panel2.add(l16);
        
        //15th text field
        tfd15 = new JTextField();
        tfd15.setBounds(630,400,150,20);
        panel2.add(tfd15);
        
        
        //second panel buttons
        //add button
        bb1 = new JButton("Add");
        bb1.setBounds(55,315,90,30);
        panel2.add(bb1);
        
        //display button
        bb3 = new JButton("Display");
        bb3.setBounds(180,315,90,30);
        panel2.add(bb3);
        
        //Go to AutoRickshaw button
        bb5 = new JButton("Go To Electric Scooter");
        bb5.setBounds(55,370,215,30); 
        panel2.add(bb5);
        
        
        //purchase electric scooter button
        bb6 = new JButton("Purchase Electric Scooter");
        bb6.setBounds(535,290,215,30);
        panel2.add(bb6);
        
        
        //sell electric scooter button
        bb2 = new JButton("Sell Electric Scooter");
        bb2.setBounds(535,445,215,30);
        panel2.add(bb2);
        
        
        //clear button
        bb4 = new JButton("Clear");
        bb4.setBounds(110,425,90,30);
        panel2.add(bb4);
        
        //ADDING panel1 to frame
        frame.add(panel);
        panel.setVisible(true);
        frame.setResizable(false);
        
        frame.add(panel2);
        panel2.setVisible(false);
        ppp1.setVisible(true);
        ppp2.setVisible(true);
        ppp3.setVisible(true);
        
        
        panel.add(b5);
        
        
        
        
        p1 = new JPanel();
        p1.setLayout(null);
        p1.setBounds(200,200,90,70);
        p1.setVisible(false);
        
    
        
        panel.add(p1);
        panel.add(pp1);
        panel.add(pp2);
        panel2.add(ppp1);
        panel2.add(ppp2);
        panel2.add(ppp3);
        
        
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this);
        
        
        
        bb1.addActionListener(this);
        bb2.addActionListener(this);
        bb3.addActionListener(this);
        bb4.addActionListener(this);
        bb5.addActionListener(this);
        bb6.addActionListener(this);
        
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==b5){
            panel2.setVisible(true);
            panel.setVisible(false);
        }
        if(e.getSource()==b1){
           
            try
            {
                int VehicleID  = Integer.parseInt(tf1.getText());
                String VehicleName = tf2.getText();
                String VehicleColor = tf3.getText();
                String VehicleSpeed = tf4.getText();
                String VehicleWeight = tf5.getText();
                String Torque = tf6.getText();
                
                int FTankCapacity = Integer.parseInt(tf8.getText());
                int EngineDisplacement = Integer.parseInt(tf17.getText());
                String GroundClearance = tf7.getText();
                
                AutoRickshaw auto = new AutoRickshaw(VehicleID, VehicleName, VehicleWeight,VehicleColor,VehicleSpeed, EngineDisplacement, Torque, FTankCapacity, GroundClearance);
                
                ccr.add(auto);
                JOptionPane.showMessageDialog(pp1,"Sucessfull! \n Press OK to continue");
                
            }catch(NumberFormatException n)
            {
                JOptionPane.showMessageDialog(pp1,"Invalid...Try Again");
            }
        }
        if(e.getSource()==b2){
            
            try{
                
            String yr =year.getSelectedItem().toString();
            String mon =month.getSelectedItem().toString();
            String da =day.getSelectedItem().toString();
            String BookedDate = yr + mon + da;
            
            int VehicleID  = Integer.parseInt(tf9.getText());
            int ChargeAmount = Integer.parseInt(tf10.getText());
            int NoOfSeats = Integer.parseInt(tf11.getText());
            
            JOptionPane.showMessageDialog(pp2,"Sucessfull! \n Press OK to continue");
            for(Vehicle obj : ccr)
            {
                if(obj instanceof AutoRickshaw)
                {
                    AutoRickshaw auto_obj = (AutoRickshaw) obj;
                    
                    if(auto_obj.getVehicleID() == VehicleID)
                    {
                        JOptionPane.showMessageDialog(pp2, "Your Booked Date is "+""+ BookedDate);
                        JOptionPane.showMessageDialog(pp2, "No of Seats are "+""+ NoOfSeats);
                        JOptionPane.showMessageDialog(pp2, "Charge Amount is " +""+ ChargeAmount);
                        
                        if(auto_obj.getIsBooked() ==true)
                        {
                            JOptionPane.showMessageDialog(pp2,"The Vehicle ID with " +" "+ VehicleID +""+ " is Booked");
                            
                        }
                        else{
                            auto_obj.BookAutoRickshaw(BookedDate, ChargeAmount, NoOfSeats);
                            
                        }   
                    }
                    else{
                        JOptionPane.showMessageDialog(pp2,"Please Enter the valid Vehicle ID.");
                    }
                }
            }
            }catch(NumberFormatException n)
        {
            JOptionPane.showMessageDialog(pp2,"Invalid...Try Again");
        }
        }
        if(e.getSource()==bb1){
            try
            {
                int VehicleID  = Integer.parseInt(tfd1.getText());
                String VehicleName = tfd2.getText();
                String VehicleColor = tfd3.getText();
                String VehicleSpeed = tfd4.getText();
                String VehicleWeight = tfd5.getText();
                
                
                int BatteryCapacity = Integer.parseInt(tfd6.getText());
                
                
                ElectricScooter elec = new ElectricScooter(VehicleID, VehicleName, VehicleWeight,VehicleColor,VehicleSpeed, BatteryCapacity );
                
                ccr.add(elec);
                JOptionPane.showMessageDialog(ppp1,"Sucessfull! \n Press OK to continue");
                
            }catch(NumberFormatException n)
            {
                JOptionPane.showMessageDialog(ppp1,"Invalid...Try Again");
            }
        }
        if(e.getSource()==bb6){
            
            try{         
            int VehicleID  = Integer.parseInt(tfd9.getText());
            String Brand = tfd10.getText();
            String ChargingTime = tfd11.getText();
            String Mileage = tfd12.getText();
            int Range  = Integer.parseInt(tfd13.getText());
            int Price  = Integer.parseInt(tfd17.getText());
            JOptionPane.showMessageDialog(ppp2,"Sucessfull! \n Press OK to continue");
            for(Vehicle ref : ccr)
            {
                if(ref instanceof ElectricScooter)
                {
                    ElectricScooter elec_obj = (ElectricScooter) ref;
                    
                    if(elec_obj.getVehicleID() == VehicleID)
                    {
                        JOptionPane.showMessageDialog(ppp2, "Your Brand is "+""+ Brand);
                        JOptionPane.showMessageDialog(ppp2, "The Price is "+""+ Price);
                        JOptionPane.showMessageDialog(ppp2, "The Charging Time is "+""+ ChargingTime);
                        JOptionPane.showMessageDialog(ppp2, "The Mileage is " +""+ Mileage);
                        JOptionPane.showMessageDialog(ppp2, "The Range is " +""+ Range);
                        
                        if(elec_obj.getHasPurchased() ==true)
                        {
                            JOptionPane.showMessageDialog(ppp2,"The Vehicle ID with " +" "+ VehicleID +""+ " has been purchased");
                            
                        }
                        else{
                            elec_obj.purchase(Brand,Price,ChargingTime,Mileage,Range);
                            
                        }   
                    }
                    else{
                        JOptionPane.showMessageDialog(ppp2,"Please Enter the valid Vehicle ID.");
                    }
                }
            }
            }catch(NumberFormatException n)
        {
            JOptionPane.showMessageDialog(ppp2,"Invalid...Try Again");
        }
        }
         if(e.getSource()==bb2){
            
            try{         
            int VehicleID  = Integer.parseInt(tfd14.getText());
            int Price  = Integer.parseInt(tfd15.getText());
            JOptionPane.showMessageDialog(ppp3,"Sucessfull! \n Press OK to continue");
            for(Vehicle refff : ccr)
            {
                if(refff instanceof ElectricScooter)
                {
                    ElectricScooter elec_sell = (ElectricScooter) refff;
                    
                    if(elec_sell.getVehicleID() == VehicleID)
                    {
                        JOptionPane.showMessageDialog(ppp3, "The Price is "+""+ Price);
                        if(elec_sell.getHasSold() ==true)
                        {
                            JOptionPane.showMessageDialog(ppp3,"The Vehicle ID with " +" "+ VehicleID +""+ " is sold out");
                            
                        }
                        else{
                            elec_sell.sell(Price);
                            
                        }   
                    }
                    else{
                        JOptionPane.showMessageDialog(ppp3,"Please Enter the valid Vehicle ID.");
                    }
                }
            }
            }catch(NumberFormatException n)
        {
            JOptionPane.showMessageDialog(ppp3,"Invalid...Try Again");
        }
        }
        if(e.getSource()==bb5){
            panel.setVisible(true);
            panel2.setVisible(false);
        }
        if(e.getSource()==b4){
            tf1.setText("");
            tf2.setText("");
            tf3.setText("");
            tf4.setText("");
            tf5.setText("");
            tf6.setText("");
            tf7.setText("");
            tf8.setText("");
            tf9.setText("");
            tf10.setText("");
            tf11.setText("");
            tf17.setText("");
        }
        if(e.getSource()==bb4){
            tfd1.setText("");
            tfd2.setText("");
            tfd3.setText("");
            tfd4.setText("");
            tfd5.setText("");
            tfd6.setText("");
            tfd9.setText("");
            tfd10.setText("");
            tfd11.setText("");
            tfd12.setText("");
            tfd13.setText("");
            tfd14.setText("");
            tfd15.setText("");
            tfd17.setText("");
        }
        if(e.getSource()==b3){
            for(Vehicle sw : ccr)
            {
                if(sw instanceof AutoRickshaw)
                {
                    AutoRickshaw auto_dis = (AutoRickshaw) sw;
                    auto_dis.Display();
            
                }
        
            }
        }
        if(e.getSource()==bb3){
            for(Vehicle swe : ccr)
            {
                if(swe instanceof ElectricScooter)
                {
                    ElectricScooter elec_dis = (ElectricScooter) swe;
                    elec_dis.DISPLAY();
            
                }
        
            }
        }
    }
    public static void main(String [] args){
        TransportGUI ref = new TransportGUI();
    }
}
    



